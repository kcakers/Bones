'''
Copyright (C) 2016 k44dev

Created by Albert Makac

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import bpy
from . import XMUSCLE_SYSTEM
       
class XMuscleCreate(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Create"
    bl_category = "x-muscle Sys"
    bl_idname = "OBJECT_PT_A_createMuscleSys"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
   
    @classmethod
    def poll(self, context): 
                  
        return (context.mode == 'OBJECT' or context.mode == 'POSE')                    

    def draw(self, context):
        layout = self.layout
        scn = context.scene
        scale = True
        
        col = layout.column(align = True)                              
        row = col.row()
        col.label("CREATE:")              
        col.operator("muscle.add_basic_muscle", "Add Basic Muscle", icon = 'RIGHTARROW_THIN')
        col.operator("muscle.add_muscle", "Add Stylized Muscle", icon = 'RIGHTARROW_THIN')      
        
        if context.object and context.object.type == 'MESH':
            if not "Muscle_XID" in context.object.keys():
                col = layout.column(align = False)
                col.operator("muscle.convert_to_muscle", "Convert Mesh to Muscle", icon = 'INLINK')
                scale = False
                            
        col = layout.column(align = True)
        if scale: 
            row = col.row()
            row.prop(scn, "Muscle_Scale", "Muscle Scale", slider =  True)
        row = col.row()
        row.label(icon = 'CURSOR')
        row.label("Targeting Method")
        row = col.row()      
        row.prop(scn, "Create_Type", expand=True)   
        if scn.Create_Type == 'AUTOAIM':        
            context.selected_order_pose_bones
            
        row = col.row()      
        row.label("Muscle Name:")                           
        row = col.row()
        row.prop(scn, "Muscle_Name", text = "", icon='FORCE_LENNARDJONES')                           
        row.operator("muscle.rename_muscle", text="", icon = 'HAND')      
        row = col.row()      
        row.label("Affixes:")                  
        row = col.row()      
        row = col.row()      
        row = col.row()      
        row.label(icon = 'TEXT')  
        row.prop(scn, "use_Affixes", "use Affixes")     
        row = col.row()
        if scn.use_Affixes:
            row = col.row()
            row.label("Prefix:")
            row.label("Suffix:")
            row = col.row()
            row.prop(scn, "Prefix","")
            row.prop(scn, "Suffix","")
        else:
            row = col.row()
            row.label(text="Use affixes for special features")
            row.label("", icon='PLUGIN')
        

class XMuscleSystem(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Muscle"
    bl_category = "x-muscle Sys"
    bl_idname = "OBJECT_PT_B_MuscleGeneralSys"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_context = "objectmode"

    @classmethod
    def poll(self, context): 
        
        if context.active_object == None:
            return False
        return context.object and context.object.type == 'MESH' and context.active_object.select == True and "Muscle_XID" in context.object.keys()
                    
    def draw(self, context):
    
        if not "Muscle_XID" in context.object.keys():
            return
        
        layout = self.layout
        obj = context.object
        scn = context.scene        
                       
        softbody = obj.soft_body
        col = layout.column(align=True)
        
        col.label(text="Muscle Mesh", icon='MOD_ARMATURE')                 
                       
        row = col.row(align = True) 

        split = row.split(percentage=0.85)
        row = split.row()
        row.prop(obj, "Muscle_Render")
        row.prop(obj, "Muscle_View3D")        
        row = col.row(align = True)
        row.label(text="")        
        row = col.row(align = True)
        row.label(text="Resolution:")       
        row.prop(obj, "View3D_Resolution", "View3D",slider = False)
        row.prop(obj, "Render_Resolution", "Render", slider = False)   
        col = layout.column(align=True)
        col.prop(obj, "Muscle_Type_INT", "Flexor to Extensor")
        col.prop(obj, "Base_Length_INT", slider = True)       
        col.prop(obj, "Muscle_Shape", slider = True)         
        col.prop(obj, "Volume_INT", slider = True)
        
        col.prop(obj, "Muscle_Size", slider = True)
        
        col = layout.column(align=False)
        col = layout.column(align=False)
        col = layout.column(align=True)
        
        col.label(text="Muscle Dynamics", icon='POSE_HLT')
        row = col.row(align = True)
        split = row.split(percentage=0.85)
        row = split.row()
        row.prop(obj, "Dynamics_Render")
        row.prop(obj, "Dynamics_View3D") 
        row = col.row(align = True)    
        row.label(text="Jiggle:")        
        col.prop(obj, "Jiggle_Springiness", slider = True)
        col.prop(obj, "Jiggle_Stiffness", slider = True)
        col.prop(obj, "Jiggle_Mass", slider = True)
        col.prop(obj, "Jiggle_Damping", slider = True)               
        col.prop_search(softbody, "vertex_group_mass", obj, "vertex_groups", text="Vertex Group")    
        
        #row is a single row, column groups them together instead     
        row = col.row(align=False)
        row = layout.row()
        row.operator("muscle.smart_update", "Smart Update", icon = "FILE_REFRESH")
        row = layout.row()
        col = layout.column(align=True)
        col.label(text="Skin microController", icon='UV_SYNC_SELECT')       
        col.label(text="Setup:")
        col = layout.column(align=True)
        col.prop(scn, "Micro_Distance", "Distance", slider = True) 
        col.prop(scn, "Micro_Influence", "Influence", slider = True)    
        col.prop(scn, "Micro_Radius", "Radius", slider = True)      
        if obj.Micro_Controller:
            col.operator("muscle.set", "Set", icon = "OUTLINER_OB_LAMP")
        col.prop(obj, "Micro_Controller", "microController")
        if obj.Micro_Controller:
            row = layout.row()
            row = layout.row(align = True) 
            split = row.split(percentage=0.85)
            row = split.row()
            row.prop(obj, "Micro_Controller_Render")
            row.prop(obj, "Micro_Controller_View3D") 
            row = layout.row(align = True)                            
            row = layout.row()
            row.prop(obj, "Skin_Tension", "Skin Tension", slider = True)
            row = layout.row()
        row.label(text="")        
        row = layout.row()
        row.operator("muscle.reset_props", "Reset Properties", icon = "LOAD_FACTORY")
        row = layout.row()        
           
class XMuscleDisplay(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Display"
    bl_category = "x-muscle Sys"
    bl_idname = "OBJECT_PT_C_muscleDispSys"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'         
    
    @classmethod
    def poll(self, context): 
       # return context.object and context.object.type == 'MESH'          
        return (context.mode == 'OBJECT' or context.mode == 'POSE')
        
    def draw(self, context):     
           
        current_theme = bpy.context.user_preferences.themes[0].view_3d
        
        layout = self.layout
        row = layout.row()        
                    
        if context.object != None:
               
            if "Muscle_XID" in context.object.keys() and context.object.type == 'MESH' and context.active_object != None: 
                if context.active_object.select == True:
                    obj = context.object
                    scn = context.scene
                    
                    mat = obj.active_material
                    row = layout.row(align = True)
                    if mat:
                        row.prop(current_theme, "object_grouped_active", text = "", icon = 'COLOR')  
                        row.prop(mat, "diffuse_color", text="", icon = 'COLOR')         
                    
                    row.operator("muscle.set_materials", "Use Material Set", icon= 'MATERIAL')     
                    
                    col = layout.column(align = True)                              
                    row = col.row(align= True)
                    row.operator("muscle.visibility", "Visibility", icon = 'RESTRICT_VIEW_OFF')        
                    row.operator("muscle.dispnames", "Names", icon = 'SORTALPHA')
                    row = col.row(align= True)        
                    row.operator("muscle.xray", "X-Ray", icon ="X")                
                    row.operator("muscle.wireframe", "Wireframe", icon = 'WIRE')
                    row = col.row(align= True)        
                    row.prop(scn, "Show_MicroControllers", icon = 'UV_SYNC_SELECT')
                    return
          
        row.operator("muscle.visibility", "Visibility", icon = 'RESTRICT_VIEW_OFF')       
           
                       
        
class XMusculature(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Musculature"
    bl_category = "x-muscle Sys"
    bl_idname = "OBJECT_PT_D_musculatureSys"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'TOOLS'
    bl_context = "objectmode"

    @classmethod
    def poll(self, context):         
        if context.active_object == None:
            return False          
        return context.object and context.object.type == 'MESH' and context.active_object.select == True
        
    def draw(self, context):
       
        found = False
        layout = self.layout        
        obj = context.object    
        scn = context.scene
        
        for ob in  context.selected_objects:
            if ob.type == 'MESH':
                if  len(context.selected_objects) > 1 and "Muscle_XID" in ob.keys():      
                    found = True
                    break
        col = layout.column(align=True)                
        row = col.row(align = True)            
                          
        if "Muscle_XID" in context.object.keys():                                                   
            
            row.label("X-Musculature:")  
            row = col.row()                         
            box = row.box() 
                #fixme error
            if context.active_object != None:
                if context.active_object.type == 'MESH':  
                    if context.active_object.users_group[0]:
                        box.label(text = context.active_object.users_group[0].name)
            row = col.row()                         
            row.label(text = "") 
            row = col.row()                         
            
            row = col.row()                                                
            row.operator("muscle.selectsingle", "Select Muscle", icon='BORDER_LASSO')   
            row = col.row()  
            row.operator("muscle.selectall", "Select X-Musculature", icon='BORDER_RECT')   
            row = col.row()             
            row.operator("muscle.xmirror", "X-Mirror Muscles", icon='MOD_MIRROR')     
            row = col.row()             
            row.label(icon = 'COLLAPSEMENU')              
            row.prop(scn, "Keep_Over_Subdiv", text = "Keep over Subdiv")
            row = col.row()
            
            row.label(icon = 'STICKY_UVS_LOC')              
            row.prop(scn, "Allow_Duplications", text = "Allow Duplications")  
            row = col.row()              
            
        if context.active_object != None:
            if context.active_object.type != 'MESH':
                found = False
            if "Muscle_XID" in context.active_object.keys():
                found = False   
                            
        if found:       
                  
            row.label(text="Active Object: " + obj.name)  
            row = col.row()
            row.label(text="")  
            row = col.row()
            row.label(icon = 'RECOVER_AUTO')              
            row.prop(scn, "Perform_Clean", text = "Perform Clean")  
            row = col.row()
            
            row.label(icon = 'COLLAPSEMENU')              
            row.prop(scn, "Keep_Over_Subdiv", text = "Keep over Subdiv")  
            row = col.row()
            
            row.label(icon = 'STICKY_UVS_LOC')              
            row.prop(scn, "Allow_Duplications", text = "Allow Duplications")  
            row = col.row()           
            row.operator("muscle.apply_musculature", "Apply Muscles to Body", icon = 'OUTLINER_OB_ARMATURE')                  
            row = col.row()        
           # row.label(text="", icon='GROUP_VERTEX')              
           #row.label("vertex group for current muscle on skin ")
                           


 
def register():

    XMUSCLE_SYSTEM.register()
     
    bpy.utils.register_class(XMuscleCreate)
    bpy.utils.register_class(XMuscleSystem)
    bpy.utils.register_class(XMuscleDisplay)            
    bpy.utils.register_class(XMusculature)
        

def unregister():
    bpy.utils.unregister_class(XMuscleCreate)  
    bpy.utils.unregister_class(XMuscleSystem)                          
    bpy.utils.unregister_class(XMuscleDisplay)                          
    bpy.utils.unregister_class(XMusculature)                          
     
    XMUSCLE_SYSTEM.unregister()

     
    
       
       